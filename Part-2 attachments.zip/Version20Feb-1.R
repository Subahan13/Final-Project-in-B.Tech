# checking working directory
#getwd()
# setting working directory
#setwd('/home/telraswa/Downloads/')
# creating data frame
df=read.csv('Data_Set.csv')
#df
# checking size of data frame
#nrow(df)

# analysing columns from data frame
#head(df)

# analysing the structure and data type of each col
#str(df)

# creating dummy variables on crop type
df$Dummy_crop_Rice=ifelse(df$Crop=="Rice",0,1)
df$Dummy_crop_Wheat=ifelse(df$Crop=="Wheat",0,1)
df$Dummy_crop_Pigeon=ifelse(df$Crop=="Pigeon Pea",0,1)

#df
#str(df)
# sampling the data set 
set.seed(2)
df$ind=sample(2,nrow(df),replace = TRUE, prob = c(0.7,0.3))

# divided dataset in training and testing part

trainData=df[(df$ind==1),]

testData=df[(df$ind==2),]

# slicing data frame
trainData=trainData[2:10]
testData=testData[2:10]
testData=testData[-3]

trainData=trainData[-3]

trainData
#testData

# RandomForest package installation
#install.packages("randomForest")

# RandomForest library calling
library(randomForest)

# model building
model=randomForest(Yield~Temprature
                   +Humidity
                   +Dummy_crop_Pigeon
                   +Dummy_crop_Wheat
                   +Dummy_crop_Rice
                   ,data = trainData,ntree=600,mtry=2)

# prediction on the basis of builted model
pred=predict(model,testData,type = c("class"))

# finding accuracy matrix accuracy=(TP+TN)/(TP+TN+FP+FN)
table(as.character(testData$Yield),as.character(pred))
pred

# importing validation datafile
validation=read.csv('Validation_Data_Set.csv')
#validation
validation$Dummy_crop_Rice=ifelse(validation$Crop=="Rice",0,1)
validation$Dummy_crop_Wheat=ifelse(validation$Crop=="Wheat",0,1)
validation$Dummy_crop_Pigeon=ifelse(validation$Crop=="Pigeon Pea",0,1)

#str(validation)
#validation=validation[-4]
validation=validation[2:9]
validation
# predicting yeild condition
test1=predict(model,validation,type = c("class"))
validation$prediction=test1

#checking status with all independent and dependent variable

#validation
